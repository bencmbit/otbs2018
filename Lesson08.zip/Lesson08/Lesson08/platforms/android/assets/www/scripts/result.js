﻿(function () {
    "use strict";

    $(document).ready(function () {

        // Declare variables
        var BasicSalary, ItemsSold, Commission, Minimum;
        var TotalSalary;
        var ShowOutput;

        // Transfer back from local memory storage to variables
        BasicSalary = localStorage.getItem("BasicSalary");
        ItemsSold = localStorage.getItem("ItemsSold");
        Commission = localStorage.getItem("Commission");
        Minimum = localStorage.getItem("Minimum");
        TotalSalary = localStorage.getItem("TotalSalary");

        // Generate a long string for output
        ShowOutput = "<p>Basic Pay : $<b>" + BasicSalary + "</b></p>";
        ShowOutput += "<p>Items Sold : <b>" + ItemsSold + "</b></p>";
        ShowOutput += "<p>Commission : <b>" + Commission + "</b></p>";
        //ShowOutput += "<p>Minimum : <b>" + Minimum + "</b></p>";
        ShowOutput += "<p><b>Nett Pay : <u>$" + TotalSalary + "</u></b></p>";

        // Display output on result.html
        $("#ShowOutput").html(ShowOutput); 

    });

})();