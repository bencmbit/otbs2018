﻿(function () {
    "use strict";

    $(document).ready(function () {
        $("#btnClickMe").bind("click", function () {
            // test();
            WageCompute();
        });
    });

    function WageCompute() {
        var JohnSalary = wages(44, 8);
        var JaneSalary = wages(32, 10);
        var SumSalary = JohnSalary + JaneSalary;

        var outputText = "";
        outputText += "<br>John's Wage is " + JohnSalary;
        outputText += "<br>Jane's Wage is " + JaneSalary;
        outputText += "<br><br> Total Wages will be " + SumSalary;

        document.getElementById("demo").innerHTML = outputText;
    }


    function test() {
        // 4 ways to output 

        // (1) You can use an alert box to display data:
        // alert("Base Code working!");

        // (2) For testing purposes, it is convenient to use document.write()
        // Using document.write() after an HTML document is loaded, will delete all existing HTML:
        // document.write("<p>Base Code is working again</p>");

        // (3) For debugging purposes, you can use the console.log() method to display data.
        console.log("Base Code is working");

        // (4) To access an HTML element, JavaScript can use the document.getElementById(id) method.
        // The id attribute defines the HTML element.
        // The innerHTML property defines the HTML content:
        document.getElementById("demo").innerHTML = "Base Code is working";
    }

})();