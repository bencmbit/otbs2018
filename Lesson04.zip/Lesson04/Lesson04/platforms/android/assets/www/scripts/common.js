﻿// Common functions used in this project environment

function wages(HoursWorked, HourlyRate) {
    var TotalSalary = HoursWorked * HourlyRate;
    return TotalSalary;
}