﻿(function () {
    "use strict";

    $(document).ready(function () {
        $("#btnCalculate").bind("click", function () {

            // Compute Salary
            CalculateSalary();

            // Redirect to result.htm
            window.location = "result.html"; 
        });
    });

    function CalculateSalary() {
        // Declare variables
        var BasicSalary, ItemsSold, Commission, Commission13, Commission46, Commission7, Minimum;
        var TotalSalary;

        // Capture inputs from wage form
        BasicSalary = parseFloat($("#txtBasicSalary").val());
        ItemsSold = parseFloat($("#txtItemsSold").val());

        //Commission = parseFloat($("#txtCommission").val());
        //Minimum = parseFloat($("#txtMinimum").val());

        Commission13 = parseFloat($("#txtCommission13").val());
        Commission46 = parseFloat($("#txtCommission46").val());
        Commission7 = parseFloat($("#txtCommission7").val());



        // Test
        //alert("BasicSalary" + BasicSalary);
        //alert("ItemsSold" + ItemsSold);
        //alert("Commission" + Commission);
        //alert("Minimum" + Minimum);

        TotalSalary = BasicSalary;
        Commission = 0;

        //if (ItemsSold >= Minimum) {
        //    TotalSalary += ItemsSold * Commission;
        //}

        if (getRadioValue("rdoDiscipline") == "FALSE") {

            if ((ItemsSold >= 1) && (ItemsSold <= 3)) {
                Commission = Commission13;
            } else if ((ItemsSold > 3) && (ItemsSold <= 6)) {
                Commission = Commission46;
            } else if (ItemsSold > 6) {
                Commission = Commission7;
            } else {
                Commission = 0;
            }

        } else {
            Commission = 0;
        }
         

        TotalSalary += ItemsSold * Commission;

        // Transfer variables to local memory storage
        localStorage.setItem("BasicSalary", BasicSalary);
        localStorage.setItem("ItemsSold", ItemsSold);
        localStorage.setItem("Commission", Commission);
        // localStorage.setItem("Minimum", Minimum);
        localStorage.setItem("TotalSalary", TotalSalary);
    }

})();