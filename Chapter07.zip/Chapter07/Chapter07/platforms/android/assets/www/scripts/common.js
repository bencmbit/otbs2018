﻿/*
This function has been shared by a programmer on StackOverflow here: http://stackoverflow.com/questions/15839169/how-to-get-value-of-selected-radio-button.
*/
function getRadioValue(groupName) {
    var _result;
    try {
        var o_radio_group = document.getElementsByName(groupName);
        for (var a = 0; a < o_radio_group.length; a++) {
            if (o_radio_group[a].checked) {
                _result = o_radio_group[a].value;
                break;
            }
        }
    }
    catch (e) {
    }
    return _result;
}



function wages(hoursWorked, hourlyRate) {
    var totalsalary = hoursWorked * hourlyRate;
    return totalsalary;
} 