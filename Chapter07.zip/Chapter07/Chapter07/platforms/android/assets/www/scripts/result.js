﻿(function () {
    "use strict";

    $(document).ready(function () {
 
        var BasicSalary, ItemsSold, Commission, Minimum, TotalSalary;
        var ShowOutput;

        // Transfer variables to local memory storage
        BasicSalary = localStorage.getItem("BasicSalary");
        ItemsSold = localStorage.getItem("ItemsSold");
        Commission = localStorage.getItem("Commission");
        Minimum = localStorage.getItem("Minimum");
        TotalSalary = localStorage.getItem("TotalSalary");

        ShowOutput = "<P>Basic Salary : <b>$" + BasicSalary +"</b></P>";
        ShowOutput += "<P>Items Sold : <b>" + ItemsSold + "</b></P>";
        ShowOutput += "<P>Commission : <b>" + Commission + "</b></P>";
        // ShowOutput += "<P>Minimum Items To Be Sold: <b>" + Minimum + "</b></P>";
        ShowOutput += "<P>Total Salary : <b><u>$" + TotalSalary + "</u></b></P>";

        $("#ShowOutput").html(ShowOutput); 

    });

})();