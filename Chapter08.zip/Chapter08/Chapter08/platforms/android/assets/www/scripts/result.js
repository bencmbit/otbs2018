﻿(function () {
    "use strict";

    $(document).ready(function () {

        // Declare variables


        // Transfer back from local memory storage to variables


        // Generate a long string for output


        // Display output on result.html


    });

})();