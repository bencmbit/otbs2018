﻿(function () {
    "use strict";

    $(document).ready(function () {

        $("#salaryform").validate({
            messages: {
                txtName: "Employee name is required",
                txtRate: "Rate must be a number greater than 0",
                txtMonths: "Month must be a whole number", 
            },

            rules: {
                txtMonths: {
                    digits: true
                },
                txtRate: {
                    min: 1
                }
            }, 

            focusInvalid: false,
            submitHandler: function () {
                return false;
            },
            errorPlacement: function (error, element) { 
                error.appendTo(element.parent().parent().after());
            },
        }); 


        $("#btnCalculate").bind("click", function () {
            if ($("#salaryform").valid()) {
                calculateSalary();
            }
        });
    });

    function calculateSalary() {
        var employeename, months, rate, role, salary;
        

        employeename = $("#txtName").val();
        months = $("#txtMonths").val();
        rate = $("#txtRate").val();
        role = $("#selRole").val();

        salary = round(months * rate * role, 2); 
        if (getRadioValue("rdoDiscipline") == "TRUE") {
            salary = round(salary * 0.8, 2);
        }


        // alert(employeename); alert(months); alert(rate); alert(role);

        validationMsgs("Your Salary is $" + salary, "Salary", "OK");
        validationMsgs(months, "Months", "OK");
        validationMsgs(rate, "Rate", "OK");
        validationMsgs(role, "Role", "OK");
        validationMsgs(employeename, "Employee Name", "OK");  
    }

})();