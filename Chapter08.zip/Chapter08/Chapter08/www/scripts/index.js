﻿(function () {
    "use strict";

    $(document).ready(function () {

        $("#btnCalculate").bind("click", function () {
            
                calculateSalary();
            
        });
    });

    function calculateSalary() {
        var employeename, months, rate, role, salary;
        

        employeename = $("#txtName").val();
        months = $("#txtMonths").val();
        rate = $("#txtRate").val();
        role = $("#selRole").val();

        alert(employeename); alert(months); alert(rate); alert(role);

    }

})();