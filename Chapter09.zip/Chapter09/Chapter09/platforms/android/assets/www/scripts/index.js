﻿(function () {
    "use strict";

    $(document).ready(function () {
        $("#btnMultiply").bind("click", function () {
            multiply();
        });
    });

    function multiply() {
        var i, from, result;
        from = parseInt($("#txtFrom").val());


    }

    function multiply2() {
        var i, from, result;
        from = parseInt($("#txtFrom").val());

        
    } 



})();