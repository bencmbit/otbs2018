﻿(function () {
    "use strict";

    var Output = "<p></p>";

    $(document).ready(function () {
        $("#btnCompute").bind("click", function () {
            GenerateInterestTable();

        });
        $("#btnClear").bind("click", function () {
            var Output = "<p></p>";
            $("#ShowResults").html(Output);
        });
    });

    function GenerateInterestTable() {

        var Deposit = parseFloat($("#txtDeposit").val());
        var Rate = parseFloat($("#txtRate").val());
        var Period = parseInt($("#txtPeriod").val());
        var Interest = 0;
        var Balance = Deposit;

        Output = "<table data-role= 'table' id='InterestTable' align='center' data-flow='reflow'> <thead> <tr> <th>Year</th><th>Interest</th><th>Balance</th></tr></thead><tbody>";

        for (var i = 1; i <= Period; i++) {
            Interest = Deposit * Rate/100;
            Balance += Interest;
            Output += "<tr><td align='center'>" + i + "</td><td align='center'>$" + Interest.toFixed(2) + "</td><th align='center'>$" + Balance.toFixed(2) + "</th>";
            Deposit = Balance;
        }
        Output += "</tr></tbody></table>";
        $("#ShowResults").html(Output);
    }

})();