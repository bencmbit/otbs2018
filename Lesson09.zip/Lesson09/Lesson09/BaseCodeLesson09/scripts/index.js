﻿(function () {
    "use strict";

    var Output = "<p></p>";

    $(document).ready(function () {
	// Compute button
        $("#btnCompute").bind("click", function () {
            

        });
	// Clear Table button
        $("#btnClear").bind("click", function () {

        });
    });

    function GenerateInterestTable() {

  }

})();