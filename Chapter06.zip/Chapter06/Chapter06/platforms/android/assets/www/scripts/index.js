﻿(function () {
    "use strict";

    $(document).ready(function () {
        $("#btnCalculate").bind("click", function () {

            var HoursWorked, HourlyRate, MyWage;

            HoursWorked = $("#txtHoursWorked").val();
            HourlyRate = $("#txtHourlyRate").val();

            MyWage = wages(HoursWorked, HourlyRate);

            var WorkType = $("#selWorkType").val();
            MyWage = WorkType * MyWage; 

            var TimeDayWorked = getRadioValue("rdoTimedayworked");
            MyWage = TimeDayWorked * MyWage;

            alert("Your wage is " + MyWage);

            localStorage.setItem("HoursWorked", HoursWorked);
            localStorage.setItem("HourlyRate", HourlyRate);
            localStorage.setItem("MyWage", MyWage);

            window.location = "result.html"; 
        });
    });



})();