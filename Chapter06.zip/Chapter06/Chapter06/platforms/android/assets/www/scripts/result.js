﻿(function () {
    "use strict";

    $(document).ready(function () {
 
        var MyWage;
        MyWage = localStorage.getItem("MyWage");

        var HoursWorked;
        HoursWorked = localStorage.getItem("HoursWorked");

        var HourlyRate;
        HourlyRate = localStorage.getItem("HourlyRate");

        $("#lblMyWage").html("My Wage " + MyWage);
        $("#lblHoursWorked").html("Hours Worked " + HoursWorked);
        $("#lblHourlyRate").html("Hourly Rate " + HourlyRate);  

    });

})();