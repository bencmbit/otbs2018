﻿(function () {
    "use strict";

    $(document).ready(function () {
        $("#btnMultiply").bind("click", function () {
            // multiply();
            multiply2();
        });
    });

    function multiply() {
        var i, from, result;
        from = parseInt($("#txtFrom").val());

        $("#mybody").find("tr").remove();

        for (i = 1; i <= 10; i++) {
            result = from * i;
            $("#mybody").append(
                "<tr><td>" + from.toString() +
                "</td><td>" + i.toString() +
                "</td><td>" + result.toString() +
                "</td></tr>"
            );
        }
    }

    function multiply2() {
        var i, from, result;
        from = parseInt($("#txtFrom").val());

        $("#result").empty(); // remove the previous result outcome

        var htmlstring;

        for (i = 1; i <= 10; i++) {
            result = from * i;
            htmlstring = "<a href='#' class='ui-btn' id='btn_" + i + "'>"
                + from.toString()
                + "x"
                + i.toString()
                + "</a>";
            $("#result").append(htmlstring);

            $("#btn_" + i).bind("click", { id: result }, function (event) {
                var data = event.data;
                alert(data.id);
            });
        }
    } 



})();