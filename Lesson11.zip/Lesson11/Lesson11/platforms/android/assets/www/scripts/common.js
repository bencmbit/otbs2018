﻿/*
This function has been shared by a programmer on StackOverflow here: http://stackoverflow.com/questions/15839169/how-to-get-value-of-selected-radio-button.
*/
function getRadioValue(groupName) {
    var _result;
    try {
        var o_radio_group = document.getElementsByName(groupName);
        for (var a = 0; a < o_radio_group.length; a++) {
            if (o_radio_group[a].checked) {
                _result = o_radio_group[a].value;
                break;
            }
        }
    }
    catch (e) {
    }
    return _result;
}

/*
    This function computes the wages
*/
function wages(hoursWorked, hourlyRate) {
    var totalsalary = hoursWorked * hourlyRate;
    return totalsalary;
} 

/*
    This function is for the notification messages after the plug-in installed in config.xml
*/
function validationMsgs(message, title, button) {
    navigator.notification.alert(
        message,
        function () { },
        title,
        button
    );
}

/*
    Special function to round the number to a specified decimeal place
*/
function round(number, decimals) {
    return +(Math.round(number + "e+" + decimals) + "e-" + decimals);
}

