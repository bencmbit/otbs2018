﻿function home() {
    window.location = "index.html";
}

function hello() {
    window.location = "hello.html";
}

function goodbye() {
    window.location = "goodbye.html";
}